import csv
import json
import re
import xlrd


def proj():
	workbook = xlrd.open_workbook('data.xls')
	worksheet = workbook.sheet_by_name('data')

	d = {}
	rows = worksheet.row_values(0)
	
	i = 0
	for col in rows:
		d[col] = i
		i += 1
	files = ["10-11.csv","11-12.csv","12-13.csv","13-14.csv","14-15.csv","15-16.csv"]
	team_positions = {}
	average_position = {}
	positions = []
	for f in files:
		with open(f) as tsvfile:
		    tsvreader = csv.reader(tsvfile,delimiter = ",")
		    for line in tsvreader:
		         positions.append((int(line[0]),line[1]))	


	#col1 = worksheet.col_values(d['HomeTeam'])
	#print col1


	dof = {}

	j = 0
	form = {}
	goal_difference = {}
	#rows_all = worksheet.row_values()
	for row in range(worksheet.nrows):
		if j == 0:	
			j += 1
		else:
			dof[j] = worksheet.row_values(row)
			j += 1

	print dof[1][d['HomeTeam']]
	teams = []
	teams.append('teams')
	for yezus in range(1,11):
		teams.append(dof[yezus][d['HomeTeam']])
		teams.append(dof[yezus][d['AwayTeam']])
	#print teams
	WLD = {}

	WLD['win'] = 2
	WLD['draw'] = 1
	WLD['loss'] = 0
	form = {}
	home_value = []
	away_value = []
	i=0
	j=0
	for position in positions:
		if position[1]=="Manchester United":
			positions[j] = [position[0],"Man United"]
		if position[1]=="Manchester City":
			positions[j] = [position[0],"Man City"]
		j+=1
	for team in teams:
		if i==0:
			i+=1
		else:
			form[team] = []
			team_positions[team] = []
			goal_difference = (0,0)
			for position in positions:
				if (team in position[1] or team==position[1] or position[1] in team):
					team_positions[team].append(position[0])
	#print(teams)
	#print(positions)
	print(team_positions)
	i=0
	for team in teams:
		if i==0:
			i+=1
		else:
			print(team)
			print team_positions[team]
			s = sum(team_positions[team])
			n = len(team_positions[team])
			while n<6:
				s = s + 21
				n+=1
			average_position[team] = round(float(s)/n,1)
	print "av"
	print(average_position)
	j=0
	for row in range(worksheet.nrows):
		if j == 0:	
			j += 1
		else:
			home = dof[j][d['HomeTeam']]
			away = dof[j][d['AwayTeam']]
			result = dof[j][d['FTR']]
			goal_difference[home][0] = goal_difference[home][0] + dof[j][d['HTHG']]
			goal_difference[home][1] = goal_difference[home][1] + dof[j][d['HTAG']]
			goal_difference[away][0] = goal_difference[away][0] + dof[j][d['HTAG']]
			goal_difference[away][1] = goal_difference[away][1] + dof[j][d['HTHG']]
			if (result == 'H'):					#filing the form table based on result of the match. Keep only the 6 most recent results in the form table
				if (len(form[away]) == 6):
					form[away].pop(0)
				form[away].append(0)
				if (len(form[home]) == 6):
					form[home].pop(0)
				form[home].append(2)
			elif(result == 'A'):
				if (len(form[away]) == 6):
					form[away].pop(0)
				form[away].append(2)
				if (len(form[home]) == 6):
					form[home].pop(0)
				form[home].append(0)
			else:
				if (len(form[away]) == 6):
					form[away].pop(0)
				form[away].append(1)
				if (len(form[home]) == 6):
					form[home].pop(0)
				form[home].append(1)
			if len(form[home])<3:
				home_value.append(0.5)
			if len(form[away])<3:
				away_value.append(0.5)
			else:
				home_value.append(float(sum(form[home]))/12)
				away_value.append(float(sum(form[home]))/12)
			j+=1
	print form
	print(len(home_value))
	print(away_value)
	outer=1					
if __name__ == '__main__':
	proj()